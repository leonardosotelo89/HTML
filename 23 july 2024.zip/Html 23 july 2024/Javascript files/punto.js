function punto(x, y, r, fill){
  let svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  document.body.appendChild(svg)
  svg.setAttribute("width", "100%")
  svg.setAttribute("height", "100%")
  svg.style.position = "absolute"
  
  let puntito = document.createElementNS('http://www.w3.org/2000/svg', 'circle')
svg.appendChild(puntito)

//puntito.id = id
puntito.setAttribute("cx", x)
puntito.setAttribute("cy", y)
puntito.setAttribute("r", r)
puntito.style.fill = fill
//puntito.style.fillOpacity = fillOpacity
//puntito.style.stroke = stroke
//puntito.style.strokeWidth = strokeWidth
return puntito 
}
/*
<script src="Javascript files/punto.js"></script>
*/
//syntax punto(x, y, r, fill)
//let p1 = new punto(300,300,10,"red")