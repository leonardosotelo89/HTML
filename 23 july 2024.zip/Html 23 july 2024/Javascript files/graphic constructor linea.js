function linea(x1, y1, x2, y2, color, ancho){
  let linea = document.createElementNS("http://www.w3.org/2000/svg", 'svg')
  document.body.appendChild(linea)
  let realline = document.createElementNS("http://www.w3.org/2000/svg", 'line')
  linea.appendChild(realline)
  linea.setAttribute("width", "100%")
  linea.setAttribute("height", "100%")
  realline.setAttribute('x1', x1)
  realline.setAttribute('y1', y1)
  realline.setAttribute('x2', x2)
  realline.setAttribute('y2', y2)
  realline.setAttribute('stroke', color)
  realline.setAttribute('stroke-width', ancho)
  
  
  return linea, realline 
}

/*
//linea(x1, y1, x2, y2, color, ancho)
let zul = new linea(50, 350, 550, 350, "blue", 10)
console.log(zul)
*/
/* 
 //zul.style.strokeLinecap = 'round'
 //zul.setAttribute("stroke-linecap", "round")
 //zul.style.strokeOpacity = '0.5' 
 //zul.setAttribute("stroke-opacity", "0.5")
*/

/*
<svg width="100%" height="300">
  <g stroke="green" >
    <line x1="25" y1="275" x2="475" y2="25"
            stroke-width="25"  />
  </g>
</svg>
*/