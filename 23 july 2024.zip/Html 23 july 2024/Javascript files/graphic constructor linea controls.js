function linea(x1, y1, x2, y2, color, ancho){
  let linea = document.createElementNS("http://www.w3.org/2000/svg", 'svg')
  document.body.appendChild(linea)
  let realline = document.createElementNS("http://www.w3.org/2000/svg", 'line')
  linea.appendChild(realline)
  linea.setAttribute("width", "100%")
  linea.setAttribute("height", "100%")
  realline.setAttribute('x1', x1)
  realline.setAttribute('y1', y1)
  realline.setAttribute('x2', x2)
  realline.setAttribute('y2', y2)
  realline.setAttribute('stroke', color)
  realline.setAttribute('stroke-width', ancho)
  
  let startplusx = document.createElement('div')
  document.body.appendChild(startplusx)
  let startminusx = document.createElement('div')
  document.body.appendChild(startminusx)
  let endplusx = document.createElement('div')
  document.body.appendChild(endplusx)
  let endminusx = document.createElement('div')
  document.body.appendChild(endminusx)
  
  let startplusy = document.createElement('div')
  document.body.appendChild(startplusy)
  let startminusy = document.createElement('div')
  document.body.appendChild(startminusy)
  let endplusy = document.createElement('div')
  document.body.appendChild(endplusy)
  let endminusy = document.createElement('div')
  document.body.appendChild(endminusy)
  
  startplusx.style.backgroundColor = 'white'
  startplusx.style.width = '50px'
  startplusx.style.height = '50px'
  startplusx.style.position = 'absolute'
  startplusx.style.left = '100px'
  startplusx.style.top = '700px'
  startplusx.style.zIndex = '5'
  startplusx.style.visibility = 'visible '
  
  startminusx.style.backgroundColor = 'white'
  startminusx.style.width = '50px'
  startminusx.style.height = '50px'
  startminusx.style.position = 'absolute'
  startminusx.style.left = '0px'
  startminusx.style.top = '700px' 
  startminusx.style.zIndex = '5'
  startminusx.style.visibility = 'visible '
  
  startplusy.style.backgroundColor = 'white'
  startplusy.style.width = '50px'
  startplusy.style.height = '50px'
  startplusy.style.position = 'absolute'
  startplusy.style.left = '50px'
  startplusy.style.top = '750px'
  startplusy.style.zIndex = '5'
  startplusy.style.visibility = 'visible '
  
  startminusy.style.backgroundColor = 'white'
  startminusy.style.width = '50px'
  startminusy.style.height = '50px'
  startminusy.style.position = 'absolute'
  startminusy.style.left = '50px'
  startminusy.style.top = '650px'
  startminusy.style.zIndex = '5'
  startminusy.style.visibility = 'visible '
  
  endplusx.style.backgroundColor = 'white'
  endplusx.style.width = '50px'
  endplusx.style.height = '50px'
  endplusx.style.position = 'absolute'
  endplusx.style.left = '550px'
  endplusx.style.top = '700px' 
  endplusx.style.zIndex = '5'
  endplusx.style.visibility = 'visible '
  
  endminusx.style.backgroundColor = 'white'
  endminusx.style.width = '50px'
  endminusx.style.height = '50px'
  endminusx.style.position = 'absolute'
  endminusx.style.left = '450px'
  endminusx.style.top = '700px' 
  endminusx.style.zIndex = '5'
  endminusx.style.visibility = 'visible '
  
  endplusy.style.backgroundColor = 'white'
  endplusy.style.width = '50px'
  endplusy.style.height = '50px'
  endplusy.style.position = 'absolute'
  endplusy.style.left = '500px'
  endplusy.style.top = '750px'
  endplusy.style.zIndex = '5'
  endplusy.style.visibility = 'visible '
  
  endminusy.style.backgroundColor = 'white'
  endminusy.style.width = '50px'
  endminusy.style.height = '50px'
  endminusy.style.position = 'absolute'
  endminusy.style.left = '500px'
  endminusy.style.top = '650px'
  endminusy.style.zIndex = '5'
  endminusy.style.visibility = 'visible '


let x1plus = null;
let x1minus = null;
let y1plus = null;
let y1minus = null;
let x2plus = null;
let x2minus = null;
let y2plus = null;
let y2minus = null;


  function x1mas(){
    let x1Value = parseInt(realline.getAttribute('x1'));
    let newX1Value = x1Value + 10; // Increment the x1 value by 10
    realline.setAttribute('x1', newX1Value);
  } 
  function incrementx1(){
    x1plus = setInterval(x1mas, 100)
  }
  function incrementx1no(){
    clearInterval(x1plus)
  }
  startplusx.addEventListener('touchstart', incrementx1) 
  startplusx.addEventListener('touchend', incrementx1no)
  
  
  function x1menos() {
    let x1Value = parseInt(realline.getAttribute('x1'));
    let newX1Value = x1Value - 10; // Dicrement the x1 value by 10
    realline.setAttribute('x1', newX1Value);
  } 
  function dicrementx1(){
  x1minus = setInterval(x1menos, 100)
  }
  function dicrementx1no(){
  clearInterval(x1minus)
  }
  startminusx.addEventListener('touchstart', dicrementx1) 
  startminusx.addEventListener('touchend', dicrementx1no) 
  
  
  function y1mas(){
    let y1Value = parseInt(realline.getAttribute('y1'));
    let newY1Value = y1Value + 10; // Increment the y1 value by 10
    realline.setAttribute('y1', newY1Value);
  }
  function incrementy1(){
  y1plus = setInterval(y1mas, 100)
  }
  function incrementy1no(){
  clearInterval(y1plus)
  }
  startplusy.addEventListener('touchstart', incrementy1) 
  startplusy.addEventListener('touchend', incrementy1no) 
  
  
  function y1menos(){
    let y1Value = parseInt(realline.getAttribute('y1'));
    let newY1Value = y1Value - 10; // Dicrement the y1 value by 10
    realline.setAttribute('y1', newY1Value);
  }
  function dicrementy1(){
  y1minus = setInterval(y1menos, 100)
  }
  function dicrementy1no(){
  clearInterval(y1minus)
  }
  startminusy.addEventListener('touchstart', dicrementy1) 
  startminusy.addEventListener('touchend', dicrementy1no) 
  
  
  function x2mas(){
    let x2Value = parseInt(realline.getAttribute('x2'));
    let newX2Value = x2Value + 10; // Increment the x2 value by 10
    realline.setAttribute('x2', newX2Value);
  }
  function incrementx2(){
    x2plus = setInterval(x2mas, 100)
  }
  function incrementx2no(){
    clearInterval(x2plus)
  }
  endplusx.addEventListener('touchstart', incrementx2) 
  endplusx.addEventListener('touchend', incrementx2no) 
  
  
  function x2menos(){
    let x2Value = parseInt(realline.getAttribute('x2'));
    let newX2Value = x2Value - 10; // Dincrement the x2 value by 10
    realline.setAttribute('x2', newX2Value);
  }
  function dicrementx2(){
    x2minus = setInterval(x2menos, 100)
  }
  function dicrementx2no(){
    clearInterval(x2minus)
  }
  endminusx.addEventListener('touchstart', dicrementx2) 
  endminusx.addEventListener('touchend', dicrementx2no) 
  
  
  function y2mas(){
    let y2Value = parseInt(realline.getAttribute('y2'));
    let newY2Value = y2Value + 10; // Increment the y2 value by 10
    realline.setAttribute('y2', newY2Value);
  }
  function incrementy2(){
    y2plus = setInterval(y2mas, 100)
  }
  function incrementy2no(){
    clearInterval(y2plus)
  }
  endplusy.addEventListener('touchstart', incrementy2) 
  endplusy.addEventListener('touchend', incrementy2no) 
  
  
  function y2menos(){
    let y2Value = parseInt(realline.getAttribute('y2'));
    let newY2Value = y2Value - 10; // Dicrement the y2 value by 10
    realline.setAttribute('y2', newY2Value);
  }
  function dicrementy2(){
    y2minus = setInterval(y2menos, 100)
  }
  function dicrementy2no(){
    clearInterval(y2minus)
  }
  endminusy.addEventListener('touchstart', dicrementy2) 
  endminusy.addEventListener('touchend', dicrementy2no) 
  
 
  return linea, realline, startplusx, endplusx, startplusy, endplusy, startminusx, endminusx, startminusy, endminusy
}

/*
//linea(x1, y1, x2, y2, color, ancho)
let zul = new linea(50, 350, 550, 350, "blue", 10)
console.log(zul)
*/
/*
 //zul.style.strokeLinecap = 'round'
 //zul.setAttribute("stroke-linecap", "round")
 //zul.style.strokeOpacity = '0.5' 
 //zul.setAttribute("stroke-opacity", "0.5")
*/

/*
<svg width="100%" height="300">
  <g stroke="green" >
    <line x1="25" y1="275" x2="475" y2="25"
            stroke-width="25"  />
  </g>
</svg>
*/