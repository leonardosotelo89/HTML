let h1s = document.getElementsByTagName('h1')
setInterval(()=>{
for(let h1 of h1s) {
  let text = h1.textContent;
  let characters = text.split('');
  let coloredText = '';

  for(let char of characters) {
    let color = '#' + Math.floor(Math.random()*16777215).toString(16);
    coloredText += `<span style="color: ${color};">${char}</span>`;
  }

  h1.innerHTML = coloredText;
}
}, 100) 