function booleancollision(character, shape){
  const a = character.getBoundingClientRect();
  const b = shape.getBoundingClientRect();

  if(a.top + a.height > b.top && 
     a.top < b.top + b.height && 
     a.left + a.width > b.left &&
     a.left < b.left + b.width){
    return true ;
  }else {
    return false;
  } 
} 
export {booleancollision} ;
