export const hola1 = document.body.innerHTML += " tests to module.js document.body.innerHTML hola <br>";
export const hola2 = console.log(' tests to module.js console.log( "hola") <br>') ;
export const color = "darkblue";