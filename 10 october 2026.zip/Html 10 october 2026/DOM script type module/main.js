import {hola1, hola2, color} from "/tests to module.js";
console.log(hola1, hola2, color);
import {booleancollision} from "/collision detection.js";
console.log(booleancollision) ;



document.body.innerHTML += " main.js document.body.innerHTML hola after import <br>";
function hola(){
  document.body.innerHTML += " main.js function hola() {document.body.innerHTML hola after import} <br>";
  document.body.style.background = color;
}
hola();

