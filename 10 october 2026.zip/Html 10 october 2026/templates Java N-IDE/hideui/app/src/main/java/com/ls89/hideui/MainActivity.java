package com.ls89.hideui;


import android.app.Activity;
import android.os.Bundle;

import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;


import android.view.View;


import android.os.Build;
import android.view.Window;
import android.graphics.Color;




public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        
        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        
        // Enable JavaScript
        webSettings.setJavaScriptEnabled(true);  
        
        // Ensure links open in WebView
        webView.setWebViewClient(new WebViewClient()); 

        // Load the local HTML file from the assets folder
                  
      webView.loadUrl("file:///android_asset/index.html");
        
   
   	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Window window = getWindow();
			window.setNavigationBarColor(Color.BLACK); 
			// Change to your desired color:RED,GREEN,BLUE,YELLOW,CYAN,MAGENTA,WHITE,BLACK,TRANSPARENT
		}
   
         // Hide status bar and navigation bar
    hideSystemUI();

  } 



private void hideSystemUI() {
   
    // Enables regular immersive mode.
    
    // For "lean back" mode, remove 
    //SYSTEM_UI_FLAG_IMMERSIVE.
   
    // Or for "sticky immersive," replace it with
    // SYSTEM_UI_FLAG_IMMERSIVE_STICKY<
   
    View decorView = getWindow().getDecorView();
   
    decorView.setSystemUiVisibility(
          
            View.SYSTEM_UI_FLAG_IMMERSIVE
          
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
           
            | View.SYSTEM_UI_FLAG_FULLSCREEN
           
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
           
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
         
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
  
    );

}


  

}




