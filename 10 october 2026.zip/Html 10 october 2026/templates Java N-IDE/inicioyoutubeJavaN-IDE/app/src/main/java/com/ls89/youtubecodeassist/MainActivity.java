package com.ls89.youtubejavanide;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.webkit.WebChromeClient;

import android.view.View;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        
        // Enable JavaScript
        webSettings.setJavaScriptEnabled(true);
        
        //enable dom storage  
        webSettings.setDomStorageEnabled(true); // Necessary for some video sites like YouTube
        
        // Ensure links open in WebView
        webView.setWebViewClient(new WebViewClient()); 
        
        //add functionalities to the WebView 
        //webView.setWebChromeClient(new WebChromeClient());
webView.setWebChromeClient(new MyWebChromeClient());

        // Load an online URL
        webView.loadUrl("https://www.youtube.com");  // Replace with the URL you want to load
    }
    
    private class MyWebChromeClient extends WebChromeClient {
        private View mCustomView;
        private CustomViewCallback mCustomViewCallback;

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            // Enter full-screen
            if (mCustomView != null) {
                callback.onCustomViewHidden();
                return;
            }

            mCustomView = view;
            mCustomViewCallback = callback;

            // Set full-screen view
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
            setContentView(view);
        }

        @Override
        public void onHideCustomView() {
            // Exit full-screen
            super.onHideCustomView();
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            
        setContentView(webView);
            //setContentView(R.layout.activity_main); // Restore original view
            mCustomView = null;
            mCustomViewCallback = null;
        }
    }
}
