

package com.ls89.sound;

import android.app.Activity;
import android.os.Bundle;

import com.ls89.sound.R;

import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        
        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // Enable JavaScript

        webView.setWebViewClient(new WebViewClient());  // Ensure links open in WebView

        // Load the local HTML file from the assets folder
        webView.loadUrl("file:///android_asset/index.html");

    }

}