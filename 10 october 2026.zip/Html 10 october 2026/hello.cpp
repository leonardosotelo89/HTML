#include <iostream> 
#include <thread> // For sleep_for 
#include <chrono> // For milliseconds 
int main() { int x = 0, y = 0; // Starting position 
int dx = 1, dy = 1; // Change in position 
for (int steps = 0; steps < 10; ++steps) { // Update position 
x += dx; y += dy; // Print position 
std::cout << "Position: (" << x << ", " << y << ")\n"; // Pause for visibility
 std::this_thread::sleep_for(std::chrono::milliseconds(500)); 
 } return 0; 
 }