package com.ls89.viewandroidx;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// Fullscreen - hide status and navigation bars
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
		View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
		
	//comment or uncomment to show or hide navigation buttons
	/*	getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
		View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
		*/
		
   //comment or uncomment to show or hide action bar which display the title
		if(getSupportActionBar() != null){
		getSupportActionBar().hide();
		//getSupportActionBar().setDisplayShowTitleEnabled(false);
		}
		
		WebView webView = new WebView(this);
		setContentView(webView);
		
		WebSettings webSettings = webView.getSettings();
		
		// Enable JavaScript
		webSettings.setJavaScriptEnabled(true);
		
		// Ensure links open in WebView
		webView.setWebViewClient(new WebViewClient());
		
		// Load the local HTML file from the assets folder
		webView.loadUrl("file:///android_asset/eggshow.html");
	}
}