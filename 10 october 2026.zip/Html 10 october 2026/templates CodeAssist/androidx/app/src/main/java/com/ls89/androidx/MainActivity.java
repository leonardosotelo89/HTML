package com.ls89.androidx;


import android.os.Bundle;
import android.view.View;

import android.view.WindowManager;

import android.os.Build;
import android.view.Window;
import android.graphics.Color;

import android.webkit.WebViewClient;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_main);
		
		
		
		
        // Fullscreen - hide status and navigation bars
      // getWindow().getDecorView().setSystemUiVisibility(
      // View.SYSTEM_UI_FLAG_FULLSCREEN)
				  
      // getWindow().getDecorView().setSystemUiVisibility(
       //View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
				 
       //getWindow().getDecorView().setSystemUiVisibility(
	  // View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
	   //View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

   
       // getSupportActionBar().setDisplayShowTitleEnabled(false);
		
	// Hide the status bar for fullscreen mode
	getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		//hide the action bar
		if (getSupportActionBar() != null) {
			getSupportActionBar().hide();
		}
		
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Window window = getWindow();
			window.setNavigationBarColor(Color.BLACK); 
			// Change to your desired color:RED,GREEN,BLUE,YELLOW,CYAN,MAGENTA,WHITE,BLACK,TRANSPARENT
		}
		
		
		
		
       // webView = findViewById(R.id.webView);
	   
	   WebView webView = new WebView(this);
	   setContentView(webView);
	   
        webView.getSettings().setJavaScriptEnabled(true);
		
		
		
		
		// Ensure links open in WebView & makes window.location.reload() works
		webView.setWebViewClient(new WebViewClient());
		
        // Load the local HTML file
        webView.loadUrl("file:///android_asset/index.html");
		
    }
}