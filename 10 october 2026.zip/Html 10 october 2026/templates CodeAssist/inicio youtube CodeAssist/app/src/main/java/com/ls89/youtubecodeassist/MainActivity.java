package com.ls89.youtubecodeassist;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

import android.webkit.WebChromeClient;

public class MainActivity extends AppCompatActivity {
	WebView webView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		WebView webView = new WebView(this);
		setContentView(webView);
		
		WebSettings webSettings = webView.getSettings();
		
		
		// Fullscreen - hide status and navigation bars
		// getWindow().getDecorView().setSystemUiVisibility(
		// View.SYSTEM_UI_FLAG_FULLSCREEN)
		
		// getWindow().getDecorView().setSystemUiVisibility(
		//View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
		
		//getWindow().getDecorView().setSystemUiVisibility(
		//View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
		
	/*	getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
		View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); */
		
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
			getWindow().setNavigationBarColor(getResources().getColor(android.R.color.black));
		}
		
	//	getSupportActionBar().setDisplayShowTitleEnabled(false);
		
		if (getSupportActionBar() != null) {
			getSupportActionBar().hide();
		}
		
		webView.getSettings().setJavaScriptEnabled(true);
		webSettings.setDomStorageEnabled(true); // Necessary for some video sites like YouTube
		
		
		// Set WebViewClient to prevent opening in browser
		webView.setWebViewClient(new WebViewClient());
		
		//add functionalities to the WebView
		webView.setWebChromeClient(new WebChromeClient());
		
		// Load the HTML url
		webView.loadUrl("https://youtube.com");
	}
}