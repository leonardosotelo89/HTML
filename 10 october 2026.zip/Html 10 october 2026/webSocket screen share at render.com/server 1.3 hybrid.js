//(versión hybrid 100% ES Module funcional en Render)
import http from "http";
import { WebSocketServer } from "ws";

const server = http.createServer();
const wss = new WebSocketServer({ server });

// Para identificación de clientes
let nextId = 1;

wss.on("connection", (ws) => {
  ws.id = "client_" + nextId++;
  console.log("connected:", ws.id);

  ws.on("message", (msg, isBinary) => {
    // 1) Si es binario → **reenviar directo al viewer**
    if (isBinary) {
      for (const client of wss.clients) {
        if (client !== ws && client.readyState === 1) {
          client.send(msg, { binary: true });
        }
      }
      return;
    }

    // 2) Si es texto → parsear JSON
    let data;
    try {
      data = JSON.parse(msg.toString());
    } catch {
      return;
    }

    // Mensaje esperado: {type, to, from, payload}
    if (data.to) {
      // enviar solo a destinatario específico
      for (const client of wss.clients) {
        if (client.readyState === 1 && client.id === data.to) {
          client.send(JSON.stringify(data));
        }
      }
    } else {
      // broadcast simple
      for (const client of wss.clients) {
        if (client !== ws && client.readyState === 1) {
          client.send(JSON.stringify(data));
        }
      }
    }
  });

  ws.on("close", () => console.log("disconnected:", ws.id));
});

server.listen(process.env.PORT || 8080, () =>
  console.log("Hybrid signaling server running on port", process.env.PORT || 8080)
);
/*
¿Qué resuelve este híbrido?

Mensaje binario = lo reenvía sin tocarlo
Perfecto para screen-share, webcam o frames comprimidos.

Mensaje JSON = signalling tradicional
Ideal para handshake entre sender/viewer.

No usa require, así que Render ya no llora.

Funciona idéntico a tu server antiguo, pero mejorado.

Sender.js (envía binario) – minimal
const ws = new WebSocket("wss://tu-render-url");

ws.onopen = () => {
  ws.send(JSON.stringify({ type:"hello", id:"sender" }));
};

function sendFrame(buffer) {
  ws.send(buffer); // binario = perfecto
}

Viewer.js (recibe binario) – minimal
const ws = new WebSocket("wss://tu-render-url");

ws.onmessage = (ev) => {
  if (typeof ev.data !== "string") {
    // es binario
    renderFrame(ev.data);
    return;
  }

  const json = JSON.parse(ev.data);
  console.log("JSON:", json);
};
*/
