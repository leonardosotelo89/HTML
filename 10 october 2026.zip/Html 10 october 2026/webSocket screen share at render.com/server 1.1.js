//common js 
const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 8080 });

let viewers = [];

wss.on("connection", (ws) => {
  ws.on("message", (msg) => {
    // retransmitir a todos excepto al que envió
    for (const v of viewers) {
      if (v !== ws && v.readyState === WebSocket.OPEN) v.send(msg);
    }
  });

  viewers.push(ws);

  ws.on("close", () => {
    viewers = viewers.filter(v => v !== ws);
  });
});

/*
ReferenceError: require is not defined in ES module scope, you can use import instead Nov 27 04:38:18 AM kv2vw This file is being treated as an ES module because it has a '.js' file extension and '/opt/render/project/src/package.json' contains "type": "module". To treat it as a CommonJS script, rename it to use the '.cjs' file extension.
*/
