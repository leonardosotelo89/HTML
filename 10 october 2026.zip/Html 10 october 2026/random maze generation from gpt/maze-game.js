/*
2.1 Random Maze Generation (Depth-First Search Algorithm)
javascript
*/
const canvas = document.getElementById('mazeCanvas');
const ctx = canvas.getContext('2d');

const cellSize = 40;
const cols = canvas.width / cellSize;
const rows = canvas.height / cellSize;

let maze = [];
let player = { x: 1, y: 1, size: 20 };

function generateMaze(cols, rows) {
    let maze = Array.from({ length: rows }, () => Array(cols).fill(1));
    let stack = [];
    let currentCell = { x: 1, y: 1 };

    maze[currentCell.y][currentCell.x] = 0;

    do {
        let neighbors = getNeighbors(currentCell.x, currentCell.y, maze);
        if (neighbors.length) {
            let chosenCell = neighbors[Math.floor(Math.random() * neighbors.length)];
            stack.push(currentCell);
            removeWall(currentCell, chosenCell, maze);
            currentCell = chosenCell;
        } else {
            currentCell = stack.pop();
        }
    } while (stack.length > 0);

    return maze;
}

function getNeighbors(x, y, maze) {
    const neighbors = [];

    if (x > 1 && maze[y][x - 2] === 1) neighbors.push({ x: x - 2, y });
    if (x < cols - 2 && maze[y][x + 2] === 1) neighbors.push({ x: x + 2, y });
    if (y > 1 && maze[y - 2][x] === 1) neighbors.push({ x, y: y - 2 });
    if (y < rows - 2 && maze[y + 2][x] === 1) neighbors.push({ x, y: y + 2 });

    return neighbors;
}

function removeWall(current, chosen, maze) {
    const x = (current.x + chosen.x) / 2;
    const y = (current.y + chosen.y) / 2;
    maze[y][x] = 0;
    maze[chosen.y][chosen.x] = 0;
}

maze = generateMaze(cols, rows);

/*
2.2 Drawing the Maze and Player
javascript
*/

function drawMaze(maze) {
    for (let y = 0; y < maze.length; y++) {
        for (let x = 0; x < maze[y].length; x++) {
            ctx.fillStyle = maze[y][x] === 1 ? 'black' : 'white';
            ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }
    }
}

function drawPlayer() {
    ctx.fillStyle = 'blue';
    ctx.beginPath();
    ctx.arc(player.x * cellSize + cellSize / 2, player.y * cellSize + cellSize / 2, player.size / 2, 0, 2 * Math.PI);
    ctx.fill();
}

/*
2.3 Handling Player Movement
javascript
*/

document.addEventListener('keydown', (event) => {
    switch (event.key) {
        case 'ArrowUp':
            if (maze[player.y - 1][player.x] === 0) player.y--;
            break;
        case 'ArrowDown':
            if (maze[player.y + 1][player.x] === 0) player.y++;
            break;
        case 'ArrowLeft':
            if (maze[player.y][player.x - 1] === 0) player.x--;
            break;
        case 'ArrowRight':
            if (maze[player.y][player.x + 1] === 0) player.x++;
            break;
    }
    updateGame();
});

/*
2.4 Checking for a Win and Resetting the Game
javascript
*/

function checkWin() {
    if (player.x === cols - 2 && player.y === rows - 2) {
        alert('You Win!');
        resetGame();
    }
}

function resetGame() {
    player.x = 1;
    player.y = 1;
    maze = generateMaze(cols, rows);
    updateGame();
}

function updateGame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawMaze(maze);
    drawPlayer();
    checkWin();
}

updateGame();
