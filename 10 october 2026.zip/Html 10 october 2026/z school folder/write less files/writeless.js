function basic(x, y, w, h, parent){
  let div = document.createElement('div');
  parent.append(div);
  div.style.position = 'absolute'
  div.style.left = x;
  div.style.top = y;
  div.style.width = w;
  div.style.height = h;
  return div;
}
function addclass(element, classes){
  element.className = classes
}
function left(element, x){
  element.style.left = x;
}
function top(element, x){
  element.style.top = x;
}
function right(element, x){
  element.style.right = x;
}
function bottom(element, x){
  element.style.bottom = x;
}
function width(element, x){
  element.style.width = x;
}
function height(element, x){
  element.style.height = x;
}
function parent(element, x){
  x.appendChild(element) 
}
/*
basic(x, y, w, h, parent)
addclass(element, classes)
//x must be a value between single or double quotes 
left(element, x) 
top(element, x)
right(element, x)
bottom(element, x)
parent(element, x)
*/