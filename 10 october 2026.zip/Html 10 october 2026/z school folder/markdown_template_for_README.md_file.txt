-syntax for a badge:

[![texto alternativo](url de la imagen)](url de la pagina)

importante:sin espacios entre corchetes y paréntesis 

[![text](image url)] //indica imagen clickeable

(destiny url) //indica direccion de destino

[![text](image url)](destiny url) //sintaxis completa

### Sintaxis básica
[![texto alternativo](url-imagen)](url-destino)

functional radioshow → texto alternativo (por si la imagen no carga)

https://leonardosotelo89.github.io/functional_radioshow/ls89icon.png → direccion absoluta de la imagen (un badge png)
Resultado: un badge visual.

2️⃣ Enlace que envuelve la imagen
[ IMAGEN ](URL)


Lo que está entre [ ] es clickeable

(https://leonardosotelo89.github.io/functional_radioshow) es el destino

Resultado final:
👉 Una imagen que al hacer clic te lleva a un destino
Patrón reutilizable (útil para README pro)

[![texto alternativo por si la imagen no carga](direccion absoluta de una imagen estatica)](url de la pagina web de destino)

example badge:

[![functional radioshow](https://leonardosotelo89.github.io/functional_radioshow/ls89icon300x300.png)](https://leonardosotelo89.github.io/functional_radioshow/)


-syntax for special comments: 

>[!note]
>this is the note<br>
>

>[!tip]
>this is the tip<br>
>

>[!important]
>this is the important<br>
>

>[!warning]
>this is the warning<br>
>

>[!caution]
>this is the caution<br>
>

generar titulos
# un hashtag genera un aquivalente a <h1></h1>
## dos hashtags genera un aquivalente a <h2></h2>