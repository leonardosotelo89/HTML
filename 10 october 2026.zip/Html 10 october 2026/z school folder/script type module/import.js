import{azuloscuro, point, cambiar} from '/export.js';
import{randombackgroundColor} from '/onclick functions.js';

console.log('import.js');

document.addEventListener('click', ()=>{
  cambiar(azuloscuro);
});
point(0,50);
point(100,100);
point(300,300);
point(400,300);

document.body.onclick = randombackgroundColor;
