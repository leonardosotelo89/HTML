
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const W = canvas.width;
const H = canvas.height;

// Player
const player = {
  x: W / 2,
  y: H - 60,
  w: 30,
  h: 30,
  speed: 6
};

let bullets = [];
let enemies = [];
let keys = {};

const buttons = {
  leftshoot:false, 
  rightshoot:false, 
  left:false, 
  right:false
};

// Controls
//window.addEventListener("keydown", e => keys[e.key] = true);
//window.addEventListener("keyup", e => keys[e.key] = false);
document.body.onload = function() {
  document.body.style.backgroundColor = 'darkred';
};
//document.body.ontouchstart = (e)=> console.log(e);
document.addEventListener("touchstart", e => {
 // console.log(e) ;
  if (e.target.tagName !== "BUTTON") return;

  const action = {
    id: e.target.id
  };

  if (action.id === "leftshoot") shoot();
  if (action.id === "rightshoot") shoot();
  if (action.id === "left") player.x -= player.speed;
  if (action.id === "right") player.x += player.speed;

  
  buttons[action.id] = true;
  console.log("touchstart", buttons, e, action);
  
});
document.body.ontouchend = (e)=>{
  const id = e.target.id;
  buttons[id] = false;
  console.log("touchend", buttons, id) ;
};

// Shoot
function shoot() {
  bullets.push({ x: player.x, y: player.y - 10, r: 4 });
}

// Spawn enemies
function spawnEnemy() {
  enemies.push({
    x: Math.random() * (W - 30) + 15,
    y: -30,
    r: 15,
    speed: 2 + Math.random() * 2
  });
}

// Update
function update() {
 // if (keys["ArrowLeft"]) player.x -= player.speed;
 // if (keys["ArrowRight"]) player.x += player.speed;
 // if (keys[" "]) shoot();
 if(buttons.leftshoot) shoot();
 if(buttons.rightshoot) shoot();
 if(buttons.left) player.x -= player.speed;
 if(buttons.right) player.x += player.speed;
 

  player.x = Math.max(15, Math.min(W - 15, player.x));

  bullets.forEach(b => b.y -= 8);
  bullets = bullets.filter(b => b.y > 0);

  enemies.forEach(e => e.y += e.speed);
  enemies = enemies.filter(e => e.y < H + 40);

  // Collision
  bullets.forEach((b, bi) => {
    enemies.forEach((e, ei) => {
      const dx = b.x - e.x;
      const dy = b.y - e.y;
      if (Math.hypot(dx, dy) < b.r + e.r) {
        bullets.splice(bi, 1);
        enemies.splice(ei, 1);
      }
    });
  });
}

// Draw
function draw() {
  ctx.clearRect(0, 0, W, H);

  // Player
  ctx.fillStyle = "cyan";
  ctx.fillRect(player.x - 15, player.y - 15, player.w, player.h);

  // Bullets
  ctx.fillStyle = "yellow";
  bullets.forEach(b => {
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
  });

  // Enemies
  ctx.fillStyle = "red";
  enemies.forEach(e => {
    ctx.beginPath();
    ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
    ctx.fill();
  });
}

// Loop
let enemyTimer = 0;
function loop() {
  update();
  draw();

  enemyTimer++;
  if (enemyTimer > 40) {
    spawnEnemy();
    enemyTimer = 0;
  }

  requestAnimationFrame(loop);
}

loop();

/*
Qué lo convierte en Rail Shooter


El eje Z es implícito: los enemigos “vienen hacia ti”.


No decides el avance: solo apuntas y reaccionas.


Base perfecta para:


Scroll de fondo


Power-ups


Enemigos en formación


Pseudo-3D (escalando sprites)


Transición a WebGL





Si quieres:


versión touch mobile


efecto Star Fox fake 3D


o mover esto a WebGL / shaders


Dilo. Esto escala fácil.
*/
