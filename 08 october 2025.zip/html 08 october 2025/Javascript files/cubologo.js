function cubologo(x, y, width, height) {
  let cubologo = document.createElement('div');
  //cubologo.style.backgroundColor = color;
  function colores(){
  cubologo.style.backgroundColor = `rgb(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)})`;
  setTimeout(colores, 1000)
} 
colores();
  cubologo.style.width = width;
  cubologo.style.height = height;
  cubologo.style.position = 'absolute';
  cubologo.style.top = y;
  cubologo.style.left = x;
  //cubologo.style.transform = 'rotateY(90deg)';
  
let rl = 0;
let rightleft = true;
let move = setInterval(()=>{
 if(rightleft){
  rl++;
 } else {
   rl--
 }
  if(rl >= 3600 || rl <= 0){

    rightleft = !rightleft
  }
  //cubologo.style.transform = `rotate(${rl}deg)`;
  cubologo.style.transform = `rotate(` + rl + `deg)` ;
}, 10)
  
  //cubologo.style.transition = 'transform .5s';
  document.body.appendChild(cubologo);
  return cubologo;
}
//cubologo(x, y, width, height)
//cubologo(0,0,50,50)
/*
//to modify an instance must be declared as a variable
let logo1 = new cubologo(150,0,50,50)
*/
/*
//to make a second instance
let logo2 = new cubologo(150,0,50,50)
*/
/*
//to modify a second instance
let logo2 = new cubologo(250,0,50,50)
logo2 style.borderRadius = '50%';
*/
/*
//code after the body closing tag
<script src="cubologo.js"></script>
<script>
//cubologo(x, y, width, height )
cubologo(500,10,50,50)
</script> 
*/
/*
//to create a rounded cubologo and 4 orbitals as children 
let rounded = new cubologo(300, 100,50,50)
rounded.style.borderRadius = '50%'
let orbital1 = new cubologo(0,0,15,15)
orbital1.style.borderRadius = '50%'
let orbital2 = new cubologo(35,0,15,15)
orbital2.style.borderRadius = '50%'
let orbital3 = new cubologo(35,35,15,15)
orbital3.style.borderRadius = '50%'
let orbital4 = new cubologo(0,35,15,15)
orbital4.style.borderRadius = '50%'
rounded.appendChild(orbital1)
rounded.appendChild(orbital2)
rounded.appendChild(orbital3)
rounded.appendChild(orbital4)
*/