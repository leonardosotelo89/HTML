function linea(x1, y1, x2, y2, color, ancho) {
  let linea = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  document.body.appendChild(linea);
  linea.style.position = 'absolute '
  linea.style.width = '100%'
  linea.style.height = '100%'
  let line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  line.setAttribute('x1', x1);
  line.setAttribute('y1', y1);
  line.setAttribute('x2', x2);
  line.setAttribute('y2', y2);
  line.setAttribute('stroke', color);
  line.setAttribute('stroke-width', ancho);
  
  linea.appendChild(line);
  
  return linea;
}

/*
//paste this code after body closing tag
<script src="Javascript files/linea.js"></script>
<script>
//syntax linea(x1, y1, x2, y2, color, ancho)
let primera = new linea(0, 250, 800, 250, "green", 10);
</script>
*/
