import{amarillo, point, cambiar} from '/export.js'


document.addEventListener('click', ()=>{
  cambiar(amarillo)
})
point(0,50)
point(100,100)
point(300,300)
point(400,300)