//how to make the export from the desired document: use the keyword 'export' before (variable or function) declaration 
//how to import at the beginning in destination document write as follows 
//import {variable1, variable2} from '/path to the file/file.js'

export const amarillo = 'yellow'
export const point = (x, y)=>{
  let punto = document.createElement('div')
  document.body.appendChild(punto)
  punto.style.width = '50px'
  punto.style.height = '50px'
  punto.style.backgroundColor = 'white'
  punto.style.borderRadius = '50%'
  punto.style.position = 'absolute'
  punto.style.left = x + "px"
  punto.style.top = `${y}px`
}
export function cambiar(color){
  document.body.style.background = color
}
