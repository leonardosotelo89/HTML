function typeText(words, bgcolor, textcolor, time, speed) {
  let note = document.createElement('div')
  document.body.appendChild(note)
  note.style.background = bgcolor
  note.style.color = textcolor
  note.style.fontSize = '1.2rem'
  note.style.margin = '1rem 0'
  note.style.padding = '.5rem'
  const letter = words.split('')
  letter.forEach((letter, i) => {
    setTimeout(() => note.textContent += letter, speed * i)
  })
  if (time) {
    setTimeout(() => note.remove(), speed * letter.length + time)
  } else {
    setTimeout(() => note.remove(), speed * letter.length + 350)
  }
}
/*
//syntax typeText(words, bgcolor, textcolor, time, speed)
typeText('This is a message.', 'lightblue', 'green', 5000, 70)
*/


