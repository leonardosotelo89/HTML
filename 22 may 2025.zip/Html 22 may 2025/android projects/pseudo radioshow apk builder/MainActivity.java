package com.example.elshowdelleo;

//replace all after package reference with this code
import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.webkit.WebSettings;

import android.view.View;

import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;

import android.graphics.Color; 



public class MainActivity extends Activity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView webView = new WebView(this);
	      setContentView(webView);
        


        webView.setWebViewClient(new WebViewClient());

        webView.getSettings().setJavaScriptEnabled(true);

/*
	// Fullscreen - hide status and navigation bars
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
		View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY );
*/

		/*
	//comment or uncomment to show or hide navigation buttons
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
		View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
		*/

        // Hide the Action Bar
        getActionBar().hide();
  getWindow().setNavigationBarColor(Color.BLUE);

webView.setWebChromeClient(new WebChromeClient());

//allow communication between java and javascript
webView.addJavascriptInterface(new WebAppInterface(), "Android");

        webView.loadUrl("file:///android_asset/index.html");
    }




    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        finish();
                    }
                    return true;
            }

        }
        return super.onKeyDown(keyCode, event);
    }


   public class WebAppInterface { 
   @JavascriptInterface 
   public void closeWebView() { 
   finish(); // Close the activity 
   }
   }
 

} 
