function title(){
const titleElement = document.querySelector('.title');

setInterval(() => {
  titleElement.innerText = 'leonardo';
  setTimeout(() => {
    titleElement.innerText = 'leonardo';
  }, 100);
  setTimeout(() => {
    titleElement.innerText = 'eonardo l';
  }, 200);
  setTimeout(() => {
    titleElement.innerText = 'onardo le';
  }, 300);
  setTimeout(() => {
    titleElement.innerText = 'nardo leo';
  }, 400);
  setTimeout(() => {
    titleElement.innerText = 'ardo leon';
  }, 500);
  setTimeout(() => {
    titleElement.innerText = 'rdo leona';
  }, 600);
  setTimeout(() => {
    titleElement.innerText = 'do leonar';
  }, 700);
  setTimeout(() => {
    titleElement.innerText = 'o leonard';
  }, 800);
  setTimeout(() => {
    titleElement.innerText = 'leonardo';
  }, 900);
}, 1000);
} 
document.write('leo');