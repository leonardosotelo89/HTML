import{color, point, cambiar} from '/export.js'


document.addEventListener('click', ()=>{
  cambiar(color)
})
point(0,0)
point(100,100)
point(300,300)
point(400,300)