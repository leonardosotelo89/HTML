function path(d, stroke, strokeWidth, fill, fillOpacity, strokeLinecap) {
  let svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  document.body.appendChild(svg);
  
  let path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  svg.appendChild(path);

  svg.setAttribute("width", "100%");
  svg.setAttribute("height", "100%");
  svg.style.position = "absolute";
  //svg.style.backgroundColor = 'cyan';

  path.setAttribute("d", `${d}`);

  path.style.stroke = stroke;
  path.style.strokeWidth = strokeWidth;
  path.style.fill = fill;
  path.style.fillOpacity = fillOpacity;
  path.style.strokeLinecap = strokeLinecap;
  
  return { svg, path };
}
/*
//paste this code after the body closing tag 
<script src="Javascript files/path.js"></script>
*/
/*
//syntax for the main script 
//path(d, stroke, strokeWidth, fill, fillOpacity, strokeLinecap)
//example 
path("M50,250 Q250,50 450,250 A250,250 0 1,1 50,350",
"yellow", 5, "green", 0.5,"round");
*/