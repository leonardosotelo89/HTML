function quadraticCurve(startx, starty, middlex, middley, endx, endy, stroke, strokeWidth){
let svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
document.body.appendChild(svg)
let path = document.createElementNS('http://www.w3.org/2000/svg', 'path')
svg.appendChild(path)

svg.setAttribute("width", "100%")
svg.setAttribute("height", "100%")
svg.style.position = "absolute"
//svg.style.backgroundColor = 'cyan' 

path.setAttribute("d", `M${startx},${starty} Q${middlex} ,${middley} ${endx},${endy}`)

path.style.stroke = stroke
path.style.strokeWidth = strokeWidth
path.style.fill = 'none'
path.style.fillOpacity = '0.5'
path.style.strokeLinecap = 'round'
return {svg, path} 
} 
/*
//paste this after the body closing tag
<script src="Javascript files/quadraticCurve.js"></script>
*/
/*
//syntax for the main script
//quadraticCurve(startx, starty, middlex, middley, endx, endy, stroke, strokeWidth)
//example
quadraticCurve(50,250,250,250,450,50, "yellow", 5)
*/