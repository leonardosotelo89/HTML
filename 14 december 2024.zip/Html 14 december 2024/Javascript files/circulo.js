function circulo(x, y, r, fill, fillOpacity, stroke, strokeWidth){
  let svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  document.body.appendChild(svg)
  svg.setAttribute("width", "100%")
  svg.setAttribute("height", "100%")
  svg.style.position = "absolute"
  let redondo = document.createElementNS('http://www.w3.org/2000/svg', 'circle')
svg.appendChild(redondo)

//redondo.id = id
redondo.setAttribute("cx", x)
redondo.setAttribute("cy", y)
redondo.setAttribute("r", r)
redondo.style.fill = fill
redondo.style.fillOpacity = fillOpacity
redondo.style.stroke = stroke
redondo.style.strokeWidth = strokeWidth
return redondo 
}
/*
<script src="Javascript files/circulo.js"></script>
*/
//syntax circulo(x, y, r, fill, fillOpacity, stroke, strokeWidth)
//let c1 = new circulo(300,300,50,"red", 1,"black", "3px")