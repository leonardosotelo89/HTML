// Function to modify CSS properties of an element
function modifyCSS() {
  var element = document.getElementById("example");
  element.style.color = "red";
  element.style.fontSize = "24px";
}