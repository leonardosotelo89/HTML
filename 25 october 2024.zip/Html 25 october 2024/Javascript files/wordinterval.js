//constructor function
function wordinterval(word, times){
const div1 = document.createElement('div');
document.body.appendChild(div1);
div1.style.display = 'grid';
div1.style.gridTemplateColumns = 'auto auto auto auto';
div1.style.gridTemplateRows = 'repeat(5,auto)';
div1.style.placeItems = 'center';
let counter = 0;

let interval1 = setInterval(()=>{
 let p = document.createElement('p')
     div1.appendChild(p)
     p.innerHTML= word;
     counter++
  if(counter >= times){
    clearInterval(interval1)
  }console.log(counter); 
} , 10) 
} 
/*
//code after the body closing tag
<script src="Javascript files/wordinterval.js" ></script>
<script>
//wordinterval(word, times)
wordinterval("anilina", 20);
</script>
*/